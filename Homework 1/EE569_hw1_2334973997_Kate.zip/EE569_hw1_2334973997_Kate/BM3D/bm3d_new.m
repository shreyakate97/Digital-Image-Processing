%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 
% Name:  Shreya Kate 
% ID:  2334973997 
% email:  shreyak@usc.edu 
% Submission Date: January 28, 2020 
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 

G = readraw('Corn_noisy.raw');
y = readraw('Corn_gray.raw');
z = [];
%image in matrix form
for i = 0:319
    out = G(1+(i*320):320+(i*320));
    z = [ z; out];
end

[PSNR, y_est] = BM3D(y, z, 25, 'np', 1)
figure; imshow(y_est)
y_est1 = reshape(y_est,[1,102400]);
count = writeraw(y_est1, 'Corn_noisefree_bm3d.raw');